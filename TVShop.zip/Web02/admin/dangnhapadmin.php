<?php session_start();

if (isset($_SESSION['uid'])) {
	header('Location: index.php');
}
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Đăng nhập</title>
	<style type="text/css">
	.baoloi{
		color: red;
		font-size: 14px;
	}
</style>
</head>
<body>
	<?php 
	include('../inc/myconnect.php');
	include('../inc/functionKT.php');
		if ($_SERVER['REQUEST_METHOD']=='POST')
		{
			$taikhoan=$_POST['taikhoan'];
			$matkhau=md5($_POST['matkhau']);
			$query="SELECT iduser,taikhoan,matkhau,status FROM tbluser WHERE taikhoan='{$taikhoan}' AND matkhau='{$matkhau}' AND status='1'";
			$result=mysqli_query($dbc,$query);
			kt_query($result,$query);
			if (mysqli_num_rows($result)==1)
			{
				list($iduser,$taikhoan,$matkhau,$status)=mysqli_fetch_array($result,MYSQLI_NUM);

				$_SESSION['uid']=$iduser;
				$_SESSION['taikhoan']=$taikhoan;
				header('Location: index.php');
				
		}
		else
		{
			$message="<p class='baoloi'>Tài khoản hoặc Mật khẩu không đúng hoặc tài khoản không còn hoạt động</p>";
		}
	}
	 ?>
	<div align="center">
		<img src="../images/admin.png" alt="" style=" height:200px">
		<h2>Đăng nhập hệ thống</h2>
		<form name="frmdangnhap" method="POST" autocomplete="on">
			<?php 
				if(isset($message))
				{
					echo $message;
				}
			?>
			<table>
				<tr>
					<td><strong>Tài khoản:</strong></td>
				</tr>
				<tr>
					<td><input type="text" placeholder="Mời bạn nhập Tài khoản" name="taikhoan" autofocus  required  size="70" style="line-height: 30px;">
					</td>
				</tr>
				<tr>
					<td><strong>Mật khẩu:</strong></td>
				</tr>
				<tr>
					<td><input type="password" placeholder="*****" name="matkhau" required size="70" autocomplete="off" style="line-height: 30px;"></td>
				</tr>
			</table>

			<label><input type="checkbox" name="remember" checked="true">Ghi nhớ</label>&nbsp;&nbsp;&nbsp;<a href="#" style="text-decoration: none;">Quên mật khẩu</a><br>&nbsp;&nbsp;&nbsp;<a href="/index.php" style="text-decoration: none;">Trở về trang chủ</a><br>
				<input type="submit" name="submit" value="Đăng nhập" style="width: 180px;height: 40px; background-color: #F97407; margin-top: 10px;">
			</form>
		</div>
	</body>
	</html>