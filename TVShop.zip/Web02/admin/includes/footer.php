</div>
            
        </div>
      
<div id="footer">
            <p>Phát triển bởi luantruongIT@gmail.com</p>
        </div>
    </div>

    <script src="../js/jquery.js"></script>
    <script type="text/javascript" src="../ckeditor/ckeditor.js" ></script>
    <script type="text/javascript" src="../ckfinder/ckfinder.js" ></script>
    
  <script type="text/javascript">
        new Morris.Area({
   
    element: 'chart',
    
    data: [
        { year: '2008', value: 20 },
        { year: '2009', value: 10 },
        { year: '2010', value: 5 },
        { year: '2011', value: 5 },
        { year: '2012', value: 20 }
    ],
    
    xkey: 'year',
    
    ykeys: ['value'],
   
    labels: ['Value']
    });
  </script>

    <script src="../js/bootstrap.min.js"></script>

  
    <script src="../js/plugins/morris/raphael.min.js"></script>
    <script src="../js/plugins/morris/morris.min.js"></script>
    <script src="../js/plugins/morris/morris-data.js"></script>


</body>

</html>
