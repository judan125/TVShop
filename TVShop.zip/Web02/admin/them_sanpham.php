<?php
include('includes/header.php');
?>

<style>
.baoloi{
  color: red;
}
</style>
<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <?php 
    include('../inc/myconnect.php');
    include('../inc/functionKT.php');
    if ($_SERVER['REQUEST_METHOD']=='POST') 
    {
      $error=array();
      $danhmucsp=$_POST['dmsp'];
      if (empty($_POST['tensanpham'])) {
        $error[]='tensanpham';
      }
      else
      {
        $tensp=$_POST['tensanpham'];
      }
      if (empty($_POST['giatien'])) {
        $error[]='giatien';
      }
      else
      {
        $giatien=$_POST['giatien'];
      }
      if (empty($_POST['giakm'])) {
        $error[]='giakm';
      }
      else
      {
        $giakm=$_POST['giakm'];
      }
      $kichco=$_POST['kcmh'];
      $phangiai=$_POST['dpg'];
      $mota=$_POST['noidung'];
 
if (empty($error)) {

    $target_dir = "../upload/"; 
    $target_file = $target_dir . basename($_FILES["anhavatar"]["name"]); 
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION)); 
    if(isset($_POST["submit"])) {
        $check = getimagesize($_FILES["anhavatar"]["tmp_name"]);
        if($check !== false) {
            
            $uploadOk = 1;
        } else {
            
            $uploadOk = 0;
        }
    }
   
    if (file_exists($target_file)) {
        echo "Xin lỗi, tập tin đã tồn tại";
        $uploadOk = 0;
    }
    if ($_FILES["anhavatar"]["size"] > 50000000) {
        echo "Xin lỗi, tập tin quá lớn.";
        $uploadOk = 0;
    }
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif" ) {
        echo "Xin lỗi, chỉ cho phép các tệp JPG, JPEG, PNG & GIF.";
        $uploadOk = 0;
    }
    if ($uploadOk == 0) {
        echo "Xin lỗi, tập tin của bạn không được tải lên.";
    
    } else {
        if (move_uploaded_file($_FILES["anhavatar"]["tmp_name"], $target_file)) {
            
        } else {
            echo "Xin lỗi, đã xảy ra lỗi khi tải lên tệp của bạn.";
        }
    }
    
    $anhavatar = "upload/".basename($_FILES["anhavatar"]["name"]);
    
    $thongso=$_POST['thongso'];
    $thongsoct=$_POST['thongsoct'];
    $baohanh=$_POST['baohanh'];
       if (empty($_POST['ngaytao'])) {
     $error[]='ngaytao';
   }
   else
   {
     $ngaytao=$_POST['ngaytao'];

  }
   
    if (empty($_POST['ordernum'])) {
   $ordernum=0;
 }
 else
 {
  $ordernum=$_POST['ordernum'];
}
$status=$_POST['status'];
 $query="INSERT INTO tblsanpham(danhmuc,tensp,giatien,giakm,kichco,phangiai,noidung,anh,thongso,thongsochitiet,baohanh,ngaytao,ordernum,status) VALUES ('{$danhmucsp}','{$tensp}',$giatien,$giakm,$kichco,'{$phangiai}','{$mota}','{$anhavatar}','{$thongso}','{$thongsoct}','{$baohanh}','$ngaytao',$ordernum,$status)";
 $results=mysqli_query($dbc,$query);
 kt_query($results,$query);
         if(mysqli_affected_rows($dbc)==1)
         {
          echo "<h2 style='color:green;'>Thêm mới thành công</h2>";
        }
        else
        {
          echo "<p>Thêm mới không thành công</p>";
        }
      }
      else
   {
    $message="<p class='baoloi'>Bạn hãy nhập đủ thông tin</p>";
   }
    }
    
    ?>
    <form name="frmadd_sanpham" method="POST" enctype="multipart/form-data">
      <?php 
  if (isset($message)) {
    echo $message;
  }
  ?>
      <h3>Thêm mới Sản phẩm</h3>
      <div class="form-group">
      <div style="float: left;">
       <label>Danh mục sản phẩm</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
       <select name="dmsp" style="display: block;">
         <option value="Sony">Sony</option>
         <option value="Samsung">Samsung</option>
         <option value="Panasonic">Panasonic</option>
         <option value="Toshiba">Toshiba</option>
         <option value="LG">LG</option>
       </select>
     </div>
     <div  style="float: left;">
      <label>Kích cỡ màn hình</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
       <select name="kcmh" style="display: block;">
         <option value="3243">32-43 inch</option>
         <option value="4455">44-55 inch</option>
         <option value="55">>55 inch</option>
       </select>
     </div>
     <div>
      <label>Độ phân giải</label>
       <select name="dpg" style="display: block;">
         <option value="720">HD 720P</option>
         <option value="1080">Full HD 1080P</option>
         <option value="4k">Ultra HD 4K</option>
       </select>
     </div>
      </div>
      <div class="row">
     <div class="form-group col-sm-4">
       <label>Tên sản phẩm</label>
       <input type="text" name="tensanpham" class="form-control" placeholder="Tên sản phẩm" value="<?php if(isset($_POST['tensp'])) { echo $_POST['tensp'];}//Nếu thêm bị lỗi thì thông tin trường này sẽ vẫn còn trên ô textbox?>">
     </div>
     <div class="form-group col-sm-4">
       <label>Giá tiền</label>
       <input type="number" name="giatien" class="form-control" placeholder="Giá sản phẩm">
     </div>
     <div class="form-group col-sm-4">
       <label>Giá khuyến mãi</label>
       <input type="number" name="giakm" class="form-control" placeholder="Giá khuyến mãi">
     </div>
   </div>
   <div class="row">
     <div class="form-group col-sm-6">
       <label>Thông số</label>
       <textarea id="thongso" name="thongso" class="form-control" placeholder="Thông số sản phẩm" rows="5"></textarea>
       
     </div>
     <div class="form-group col-sm-6">
       <label>Thông số chi tiết</label>
       <textarea id="thongsoct" name="thongsoct" class="form-control" placeholder="Thông số chi tiết" rows="5"></textarea>
     </div>
   </div>
     <div class="form-group">
       <label>Mô tả</label>
       <textarea id="noidung" name="noidung" class="form-control" placeholder="Mô tả"></textarea>
       
     </div>
     <div class="row">
     <div class="form-group col-sm-3">
       <label>Ảnh</label>
       <input type="file" name="anhavatar">
     </div>
     <div class="form-group col-sm-3">
       <label>Bảo hành</label>
       <input type="text" name="baohanh" class="form-control" placeholder="Bảo hành" value="<?php if(isset($_POST['baohanh'])) { echo $_POST['baohanh'];} ?> ">
     </div>
     <div class="form-group col-sm-3">
       <label>Ngày tạo</label>
       <input type="date" name="ngaytao" class="form-control" placeholder="">
     </div>
     <div class="form-group col-sm-3">
       <label>Thứ tự</label>
       <input type="number" name="ordernum" class="form-control" placeholder="Thứ tự" value="<?php if(isset($_POST['ordernum'])) { echo $_POST['ordernum'];} ?> ">
     </div>
   </div>
     <div class="form-group">
      <label for="" style="display: block;">Trạng thái</label>
      <label for="" class="radio-inline"><input type="radio" name="status" value="1" checked="checked">Hiển thị</label>
      <label for="" class="radio-inline"><input type="radio" name="status" value="0">Không hiển thị</label>
    </div>
    <input type="submit" name="submit" class="btn btn-primary" value="Thêm">
  </form>
</div>
</div>
<?php
include('includes/footer.php');
?>

