<?php ob_start();  ?>
<?php error_reporting(0); ?> 
<?php
include('includes/header.php');
?>
<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<?php 
		include('../inc/myconnect.php');
		include('../inc/functionKT.php');
    
		if(isset($_GET['id']) && filter_var($_GET['id'],FILTER_VALIDATE_INT,array('min_ranger'=>1)))
		{
			$id=$_GET['id'];
		}
		else
		{
			header('Location: list_danhmucsp.php');
			exit();
		}
		if (isset($_POST['submit'])) 
		{
			$danhmuc=$_POST['danhmuc'];
      $ordernum=$_POST['ordernum'];
			$status=$_POST['status'];

			
		$query="UPDATE tbldanhmuc SET danhmuc='{$danhmuc}',ordernum={$ordernum},status={$status} WHERE id={$id}";
		$results=mysqli_query($dbc,$query);
		kt_query($results,$query);
       if(mysqli_affected_rows($dbc)==1)
       {
       	echo "<h2 style='color:green;'>Sửa thành công</h2>";
        header('Location: list_danhmucsp.php');
       echo "<script>alert('Sửa thành công');</script>";
       }
       else
       {
       	echo "<p>Sửa không thành công</p>";
       }
   }
   $query_id="SELECT danhmuc,ordernum,status FROM tbldanhmuc WHERE id={$id}";
   $result_id=mysqli_query($dbc,$query_id);
   kt_query($query_id,$result_id);
     
   if (mysqli_num_rows($result_id)==1) 
   { 
   	list($danhmuc,$ordernum,$status)=mysqli_fetch_array($result_id,MYSQLI_NUM); 
   }
   else
   {
   	echo "Id  không tồn tại";
   }
   ?>
   <form moaction="" name="frmadd_danhmuc" method="POST" enctype="multipart/form-data">
   	<h2>Sửa Danh Mục: <?php if (isset($danhmuc)) { echo $danhmuc;  } ?></h2>
   	<div class="form-group">
   		<label for="">Danh Mục</label>
   		<input type="text" name="danhmuc" class="form-control" placeholder="Tiêu đề" value=" <?php if(isset($danhmuc)){echo $danhmuc;} ?>">
   	</div>
   	<div class="form-group">
   		<label for="">Thứ tự</label>
   		<input type="text" name="ordernum" class="form-control" placeholder="Thứ tự" value=" <?php if(isset($ordernum)){echo $ordernum;} ?> ">
   	</div>
   	<div class="form-group">
   		<label for="" style="display: block;">Trạng thái</label>
   		<?php 
   		if (isset($status)==1) 
   		{ 
   			?>
   			<label for="" class="radio-inline"><input checked="checked" type="radio" name="status" value="1" >Hiển thị</label>
   			<label for="" class="radio-inline"><input type="radio" name="status" value="0">Không hiển thị</label>
   			<?php 
   		}
   		else
   		{
   			?>
   			<label for="" class="radio-inline"><input type="radio" name="status" value="1">Hiển thị</label>
   			<label for="" class="radio-inline"><input checked="checked" type="radio" name="status" value="0" >Không hiển thị</label>
   			<?php 
   		}
   		?>   
   	</div>
   	<input type="submit" name="submit" class="btn btn-primary" value="Sửa">
   	<input type="reset" name="reset" class="btn btn-primary" value="Reset">
   </form>
</div>
</div>
<?php
include('includes/footer.php');
?>
<?php ob_flush(); ?>

