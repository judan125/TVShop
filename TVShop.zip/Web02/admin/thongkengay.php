<?php include('includes/header.php'); ?>
<?php include('../inc/myconnect.php');?>
<?php include('../inc/functionKT.php');?>
<div class="row">
<h3>DOANH THU NGÀY</h3>
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
	<form method="post" action="">
		<label>Chọn ngày: </label>
		<input type="date" name="date" required>
		<input type="submit" name="submit" value="Xem kết quả">
	</form>
    <table class="table table-hover">
			<thead>
				<tr align="center">
					<th>Tổng doanh thu</th>
					<th>Tổng đơn hàng</th>
				</tr>
			</thead>
	<?php
	
	if (isset($_POST['submit'])) {
		$date = $_POST['date'];
		
		
		$sql1 = "SELECT SUM(tongtien) as total_revenue FROM tblhoadonxuat WHERE DATE(ngaylap) = DATE('$date') AND status = 1";
		$result1 = mysqli_query($dbc, $sql1);
		$row1 = mysqli_fetch_assoc($result1);
		$total_revenue = $row1["total_revenue"];

		
		$sql2 = "SELECT COUNT(*) as total_imports FROM tblhoadonxuat WHERE DATE(ngaylap) = DATE('$date') AND status = 1";
		$result2 = mysqli_query($dbc, $sql2);
		$row2 = mysqli_fetch_assoc($result2);
		$total_imports = $row2["total_imports"]; 
        echo "<h2>Kết quả thống kê cho ngày " . date('d/mY', strtotime($date)) . ":</h2>";?>
        <tr>
				<td><?php echo $total_revenue ; ?></td>
				<td><?php echo $total_imports; ?></td>
            </tr>
    <?php }
	?>
	
            
    </table>
	</div>
</div>


<?php 
include('includes/footer.php');
?>