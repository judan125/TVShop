<?php include('includes/header.php'); ?>
<?php include('../inc/myconnect.php');?>
<?php include('../inc/functionKT.php');?>
<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<h3>Danh sách video</h3>
		<table class="table table-hover">
			<thead>
				<tr align="center">
					<th>ID</th>
					<th>Title</th>
					<th>Link</th>
					<th>Thứ tự</th>
					<th>Trạng thái</th>
					<th>Edit</th>
					<th>Delete</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					
				$query="SELECT * FROM tblvideo ORDER BY ordernum ";
				$result=mysqli_query($dbc,$query);
				kt_query($result,$query);
				while ($video=mysqli_fetch_array($result,MYSQLI_ASSOC)) {
					?>
					<tr>
						<td><?php echo $video['id']; ?></td>
						<td><?php echo $video['title']; ?></td>
						<td><?php echo $video['link']; ?></td>
						<td><?php echo $video['ordernum']; ?></td>
						<td>
							<?php
							if( $video['status']==1)
							{
								echo "Hiển thị";
							}
							else {
								echo "Không hiển thị";
							} ?>
							
						</td>
						<td><a href="edit_video.php?id=<?php echo $video['id']; ?>"><img width="21" src="../images/icon_edit.png" alt=""></a></td>
						<td><a href="delete_video.php?id=<?php echo $video['id']; ?>" onclick="return confirm('Bạn có muốn xóa không?');"><img width="21" src="../images/icon_delete.png" alt=""></a></td>
					</tr>
					<?php
				}
				?>
			</tbody>
		</table>
	</div>
</div>
<?php include ('includes/footer.php');?>