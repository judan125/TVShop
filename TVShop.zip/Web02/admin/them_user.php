<style type="text/css">
	.baoloi{
		color: red;
	}
</style>
<?php
include('includes/header.php');
?>
<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<?php 
			include('../inc/myconnect.php');
    		include('../inc/functionKT.php');
    		if ($_SERVER['REQUEST_METHOD']=='POST')
    		 {
    			$errors=array();
    			if (empty($_POST['taikhoan'])) 
    			{
    				$errors[]='taikhoan';
    			}
    			else
    			{
    				$taikhoan=$_POST['taikhoan'];
    			}
    			if (empty($_POST['matkhau'])) 
    			{
    				$errors[]='matkhau';
    			}
    			else
    			{
    				$matkhau=md5(trim($_POST['matkhau']));
    			}
    			if (trim($_POST['matkhau'])!=trim($_POST['matkhaure'])) {
    				$errors[]='matkhaure';
    			}
    			if (empty($_POST['hoten'])) 
    			{
    				$errors[]='hoten';
    			}
    			else
    			{
    				$hoten=$_POST['hoten'];
    			}
    			if (empty($_POST['dienthoai'])) 
    			{
    				$errors[]='dienthoai';
    			}
    			else
    			{
    				$dienthoai=$_POST['dienthoai'];
    			}
    			if (empty($_POST['email'])) 
    			{
    				$errors[]='email';
    			}
    			else
    			{
    				$email=$_POST['email'];
    			}
    			if (empty($_POST['diachi'])) 
    			{
    				$errors[]='diachi';
    			}
    			else
    			{
    				$diachi=$_POST['diachi'];
    			}
    			$status=$_POST['status'];
    			if (empty($errors)) {
    				$query_in="INSERT INTO tbluser(taikhoan,matkhau,hoten,dienthoai,email,diachi,status) VALUES('{$taikhoan}','{$matkhau}','$hoten',$dienthoai,'$email','$diachi',$status)";
    				$results_in=mysqli_query($dbc,$query_in);
    				kt_query($results_in,$query_in);
    				if (mysqli_affected_rows($dbc)==1) {
    					echo "<p style='color: green;'>Thêm mới thành công</p>";
    				}
    				else{
    					echo "<p style='color: red;'>Thêm mới không thành công</p>";
    				}
    			}
    			else
    			{
    				$message="<p class='baoloi'>Bạn hãy nhập đầy đủ thông tin</p>";
    			}
    		}
		 ?>
		<form moaction="" name="frmadd_video" method="POST">
			<?php 
				if (isset($message)) {
					echo $message;
				}
			 ?>
            <h2>Thêm mới User</h2>
            <div class="form-group">
              <label for="">Tài khoản</label>
              <input type="text" name="taikhoan" class="form-control" placeholder="Tài khoản" value="<?php if(isset($_POST['taikhoan'])) { echo $_POST['taikhoan']; }//Nếu thêm bị lỗi thì thông tin trường này sẽ vẫn còn trên ô textbox ?>">
              <?php 
              	if (isset($errors) && in_array('taikhoan',$errors))
              	{
              		echo "<p class='baoloi'>Tài khoản không được để trống</p>";
              	}
               ?>
            </div>
            <div class="form-group">
              <label for="">Mật khẩu</label>
              <input type="password" name="matkhau" class="form-control" placeholder="Mật khẩu" value="">
              <?php 
              	if (isset($errors) && in_array('matkhau',$errors))
              	{
              		echo "<p class='baoloi'>Mật khẩu không được để trống</p>";
              	}
               ?>
            </div>
            <div class="form-group">
              <label for="">Xác nhận Mật khẩu</label>
              <input type="password" name="matkhaure" class="form-control" placeholder="Nhập lại Mật khẩu" value="">
              <?php 
              	if (isset($errors) && in_array('matkhaure',$errors))
              	{
              		echo "<p class='baoloi'>Mật khẩu không trùng khớp</p>";
              	}
               ?>
            </div>
            <div class="form-group">
              <label for="">Họ tên</label>
              <input type="text" name="hoten" class="form-control" placeholder="Họ tên" value="<?php if(isset($_POST['hoten'])) { echo $_POST['hoten']; }//Nếu thêm bị lỗi thì thông tin trường này sẽ vẫn còn trên ô textbox ?>">
              <?php 
              	if (isset($errors) && in_array('hoten',$errors))
              	{
              		echo "<p class='baoloi'>Họ tên không được để trống</p>";
              	}
               ?>
            </div>
            <div class="form-group">
              <label for="">Số điện thoại</label>
              <input type="number" name="dienthoai" class="form-control" placeholder="Số điện thoại" value="<?php if(isset($_POST['dienthoai'])) { echo $_POST['dienthoai']; }//Nếu thêm bị lỗi thì thông tin trường này sẽ vẫn còn trên ô textbox ?>">
              <?php 
              	if (isset($errors) && in_array('dienthoai',$errors))
              	{
              		echo "<p class='baoloi'>Số điện thoại không được để trống</p>";
              	}
               ?>
            </div>
            <div class="form-group">
              <label for="">Email</label>
              <input type="email" name="email" class="form-control" placeholder="Email" value="<?php if(isset($_POST['email'])) { echo $_POST['email']; }//Nếu thêm bị lỗi thì thông tin trường này sẽ vẫn còn trên ô textbox ?>">
              <?php 
              	if (isset($errors) && in_array('email',$errors))
              	{
              		echo "<p class='baoloi'>Email không được để trống</p>";
              	}
               ?>
            </div>
            <div class="form-group">
              <label for="">Địa chỉ</label>
              <input type="text" name="diachi" class="form-control" placeholder="Địa chỉ" value="<?php if(isset($_POST['diachi'])) { echo $_POST['diachi']; }//Nếu thêm bị lỗi thì thông tin trường này sẽ vẫn còn trên ô textbox ?>">
              <?php 
              	if (isset($errors) && in_array('diachi',$errors))
              	{
              		echo "<p class='baoloi'>Địa chỉ không được để trống</p>";
              	}
               ?>
            </div>
            <div class="form-group">
              <label for="" style="display: block;">Trạng thái</label>
              <label for="" class="radio-inline"><input type="radio" name="status" value="1" checked="checked">Hoạt động</label>
              <label for="" class="radio-inline"><input type="radio" name="status" value="0">Không hoạt động</label>
            </div>
            <input type="submit" name="submit" class="btn btn-primary" value="Thêm">
          </form>
	</div>
</div>
<?php
include('includes/footer.php');
?>