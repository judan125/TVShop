<?php include('includes/header.php'); ?>
<?php include('../inc/myconnect.php'); ?>
<?php include('../inc/functionKT.php'); ?>
<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<h3>Danh sách ảnh slider</h3>
		<table class="table table-hover">
			<thead>
				<tr>
					<th>Thứ tự</th>
					<th>Mã Slider</th>
					<th>Tiêu đề</th>
					<th>Ảnh</th>
				
					<th>Trạng thái</th>
					<th>Edit</th>
					<th>Xóa</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					$query="SELECT * FROM tblslider ORDER BY ordernum";
					$result=mysqli_query($dbc,$query);
					while ($slider=mysqli_fetch_array($result,MYSQLI_ASSOC)) {
						?>
						<tr>
							<td><?php echo $slider['ordernum']; ?></td>
							<td><?php echo $slider['id']; ?></td>
							<td><?php echo $slider['title']; ?></td>
							<td><img width="60" src="../<?php echo $slider['anh']; ?>"/></td>
							<!-- <td><?php //echo $slider['link']; ?></td> -->
							
							<td>
								<?php if ($slider['status']==1) {
									echo "Hiển thị";
								}
								else{
									echo "Không hiển thị";
								} ?>
							</td>
							<td><a href="sua_slider.php?id=<?php echo $slider['id']; ?>"><img width="21" src="../images/icon_edit.png" alt=""></a></td>
							<td><a href="xoa_slider.php?id=<?php echo $slider['id']; ?>" onclick="return confirm('Bạn có muốn xóa không?');"><img width="21" src="../images/icon_delete.png" alt=""></a></td>
						</tr>
						<?php
					}
				?>
			</tbody>
		</table>
	</div>
</div>
<?php include('includes/footer.php') ?>
