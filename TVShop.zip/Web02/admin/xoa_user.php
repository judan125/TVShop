<?php 
include('../inc/myconnect.php');
include('../inc/functionKT.php');

if(isset($_GET['iduser']) && filter_var($_GET['iduser'],FILTER_VALIDATE_INT,array('min_range'=>1)))
{
	$id=$_GET['iduser'];
	$query="DELETE FROM tbluser WHERE iduser={$id}";
	$result=mysqli_query($dbc,$query);
	kt_query($result,$query);
	header('Location: list_user.php');
}
else
{
	header('Location: list_user.php');
}
?>