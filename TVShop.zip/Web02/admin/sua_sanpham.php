<?php ob_start(); ?>
<?php error_reporting(0); ?> 
<?php
include('includes/header.php');
?>
<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<?php 
		include('../inc/myconnect.php');
		include('../inc/functionKT.php');
    
		if(isset($_GET['id']) && filter_var($_GET['id'],FILTER_VALIDATE_INT,array('min_range'=>1)))
		{
			$id=$_GET['id'];
		}
		else
		{
			header('Location: list_sanpham.php');
			exit();
		}
		if (isset($_POST['submit'])) 
		{
      $danhmucsp=$_POST['dmsp'];
			$tensp=$_POST['tensanpham'];
			$giatien=$_POST['giatien'];
      $giakm=$_POST['giakm'];
      $kichco=$_POST['kcmh'];
      $phangiai=$_POST['dpg'];
      $noidung=$_POST['noidung'];
      if($_FILES['img']['size']=='')
      {
      $link_img=$_POST['anh_hid'];
   
      }
    else{
      
      if (($_FILES['img']['type']!="image/gif")
        &&($_FILES['img']['type']!="image/png")
        &&($_FILES['img']['type']!="image/jpeg")
        &&($_FILES['img']['type']!="image/jpg")) 
      {
        $message="File không đúng định dạng";
    }
    elseif ($_FILES['img']['size']>1000000) {
      $message="Kích thước phải nhỏ hơn 1MB";
    }
    
    else{
      $img=$_FILES['img']['name'];
      $link_img='upload/'.$img;
      move_uploaded_file($_FILES['img']['tmp_name'],"../upload/".$img);
    }
    
    $sql="SELECT anh FROM tblsanpham WHERE id={$id}";
    $query_a=mysqli_query($dbc,$sql);
    $anhInfo=mysqli_fetch_assoc($query_a);
    unlink('../'.$anhInfo['anh']);
    

  }
      $thongso=$_POST['thongso'];
      $thongsoct=$_POST['thongsoct'];
      $baohanh=$_POST['baohanh'];
      $ngaytao=$_POST['ngaytao'];
			$ordernum=$_POST['ordernum'];
			$status=$_POST['status'];

			
		$query="UPDATE tblsanpham SET danhmuc='{$danhmucsp}',tensp='{$tensp}',giatien={$giatien},giakm={$giakm},kichco={$kichco},phangiai='{$phangiai}',noidung='{$noidung}',anh='{$link_img}',thongso='{$thongso}',thongsochitiet='{$thongsoct}',baohanh='{$baohanh}',ngaytao='{$ngaytao}',ordernum={$ordernum},status={$status} WHERE id=$id";//kiểu số ko cần dấu nháy
		$results=mysqli_query($dbc,$query);
		kt_query($results,$query);
       if(mysqli_affected_rows($dbc)==1)
       {
       	echo "<h2 style='color:green;'>Sửa thành công</h2>";
         header('Location: list_sanpham.php');
       }
       else
       {
       	echo "<p>Sửa không thành công</p>";
       }
   }
   $query_id="SELECT danhmuc,tensp,giatien,giakm,kichco,phangiai,noidung,anh,thongso,thongsochitiet,baohanh,ngaytao,ordernum,status FROM tblsanpham WHERE id=$id";
   $result_id=mysqli_query($dbc,$query_id);
   kt_query($query_id,$result_id);
     
   if (mysqli_num_rows($result_id)==1)
    {
   	list($danhmucsp,$tensp,$giatien,$giakm,$kichco,$phangiai,$noidung,$anh,$thongso,$thongsoct,$baohanh,$ngaytao,$ordernum,$status)=mysqli_fetch_array($result_id,MYSQLI_NUM);
   }
   else
   {
   	echo "Id sản phẩm không tồn tại";
   }
   ?>
   <form moaction="" name="frmadd_slider" method="POST" enctype="multipart/form-data">
   	<h2>Sửa Sản phẩm: <?php if (isset($tensp)) { echo '<a>'.$tensp.'</a>';  } ?></h2>
   	<div class="form-group">
      <div style="float: left;">
       <label>Danh mục sản phẩm</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
       <select name="dmsp" style="display: block;">
         <option value="Sony" <?php if ($danhmucsp == 'Sony') {
              ?><?= "selected" ?>
            <?php } ?> >Sony</option>
            <option value="Samsung" <?php if ($danhmucsp == 'Samsung') {
              ?><?= "selected" ?>
            <?php } ?> >Samsung</option>
            <option value="Panasonic" <?php if ($danhmucsp == 'Panasonic') {
              ?><?= "selected" ?>
            <?php } ?> >Panasonic</option>
            <option value="Toshiba" <?php if ($danhmucsp == 'Toshiba') {
              ?><?= "selected" ?>
            <?php } ?> >Toshiba</option>
            <option value="LG" <?php if ($danhmucsp == 'LG') {
              ?><?= "selected" ?>
              <?php } ?> >LG</option>
       </select>
     </div>
     <div  style="float: left;">
      <label>Kích cỡ màn hình</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
       <select name="kcmh" style="display: block;">
         <option value="3243" <?php if ($kichco == '3242') {
              ?><?= "selected" ?>
            <?php } ?> >32-43 INCH</option>
         <option value="4455" <?php if ($kichco == '4455') {
              ?><?= "selected" ?>
            <?php } ?> >44-55 INCH</option>
         <option value="55" <?php if ($kichco == '55') {
              ?><?= "selected" ?>
            <?php } ?> >>55 INCH</option>
       </select>
     </div>
     <div>
      <label>Độ phân giải</label>
       <select name="dpg" style="display: block;">
         <option value="720" <?php if ($phangiai == '720') {
              ?><?= "selected" ?>
            <?php } ?> >HD 720P</option>
         <option value="1080" <?php if ($phangiai == '1080') {
              ?><?= "selected" ?>
            <?php } ?> >Full HD 1080P</option>
         <option value="4k" <?php if ($phangiai == '4k') {
              ?><?= "selected" ?>
            <?php } ?> >Ultra HD 4K</option>
       </select>
     </div>
   </div>
   <div class="row">
     <div class="form-group col-sm-4">
       <label>Tên sản phẩm</label>
       <input type="text" name="tensanpham" class="form-control" placeholder="Tên sản phẩm" value="<?php if(isset($tensp)) {echo $tensp;}//Nếu thêm bị lỗi thì thông tin trường này sẽ vẫn còn trên ô textbox?>">
     </div>
     <div class="form-group col-sm-4">
       <label>Giá tiền</label>
       <input type="text" name="giatien" class="form-control" placeholder="Giá sản phẩm" value="<?php if(isset($giatien)){ echo $giatien;} ?>">
     </div>
     <div class="form-group col-sm-4">
       <label>Giá khuyến mãi</label>
       <input type="text" name="giakm" class="form-control" placeholder="Giá khuyến mãi" value="<?php if(isset($giakm)){ echo $giakm;} ?>">
     </div>
   </div>
   <div class="row">
     <div class="form-group col-sm-6">
       <label>Thông số</label>
       <textarea id="textarea_tt" name="thongso" class="form-control" placeholder="Thông số sản phẩm" rows="5" value=""><?php if(isset($thongso)){ echo $thongso;} ?></textarea>
     </div>
     <div class="form-group col-sm-6">
       <label>Thông số chi tiết</label>
       <textarea id="thongsoct" name="thongsoct" class="form-control" placeholder="Thông số chi tiết" rows="5"><?php if(isset($thongsoct)){ echo $thongsoct;} ?></textarea>
     </div>
   </div>
     <div class="form-group">
       <label>Mô tả</label>
       <textarea id="noidung" name="noidung" class="form-control" placeholder="Mô tả" rows="5" value=""><?php if(isset($noidung)){ echo $noidung;} ?></textarea>
     </div>
     <div class="form-group">
      <label for="">Ảnh đại diện</label>
      <input type="file" name="img" value="">
      <img src="../<?php echo $anh; ?>" width="100" alt="">
      <input type="hidden" name="anh_hid" value="<?php echo $anh; ?> ">
     <div class="row">
     <div class="form-group col-sm-3">
       <label>Bảo hành</label>
       <input type="text" name="baohanh" class="form-control" value="<?php if(isset($baohanh)){ echo $baohanh;} ?>">
     </div>
     <div class="form-group col-sm-3">
       <label>Ngày tạo</label>
       <input type="date" name="ngaytao" class="form-control" value="<?php if(isset($ngaytao)){ echo $ngaytao;} ?>">
     </div>
     <div class="form-group col-sm-3">
       <label>Thứ tự</label>
       <input type="number" name="ordernum" class="form-control" placeholder="Thứ tự" value="<?php if(isset($ordernum)){echo $ordernum;} ?>">
     </div>
     <div class="form-group col-sm-3">
      <label for="" style="display: block;">Trạng thái</label>
      <?php 
      if (isset($status)==1) 
      { 
        ?>
        <label for="" class="radio-inline"><input checked="checked" type="radio" name="status" value="1" >Hiển thị</label>
        <label for="" class="radio-inline"><input type="radio" name="status" value="0">Không hiển thị</label>
        <?php 
      }
      else
      {
        ?>
        <label for="" class="radio-inline"><input type="radio" name="status" value="1">Hiển thị</label>
        <label for="" class="radio-inline"><input checked="checked" type="radio" name="status" value="0" >Không hiển thị</label>
        <?php 
      }
      ?>   
    </div>
    </div>
   
   	
   	<input type="submit" name="submit" class="btn btn-primary" value="Cập nhật">
   </form>
</div>
</div>
<?php
include('includes/footer.php');
?>
<?php ob_flush(); ?>