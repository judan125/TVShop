<?php session_start();
if (!isset($_SESSION['uid'])) {
    header('Location: dangnhapadmin.php');
}
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Quản trị hệ thống</title>
    
    <script type="text/javascript" src="./tinymce/vi_VN.js"></script>

  <script type="text/javascript">tinymce.init({
   selector:'textarea#textarea_tt',
   
});</script>
   
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    
    <link href="../css/sb-admin.css" rel="stylesheet">
    
    <link href="../css/plugins/morris.css" rel="stylesheet">
    
    <link href="../font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    
    
</head>
<body>
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <div id="wrapper">
     
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            
            <div class="navbar-header">

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">QUẢN TRỊ HỆ THỐNG</a>
                <div style="height: 50px;margin-left: 380px;">
                    <span style="font-size: 18px; margin-left: 150px;color: white;line-height: 50px;"><marquee behavior="alternate"> Welcome to System Administrator - LuanTruong TiVi !!!</marquee></span>
                </div>
            </div>

            
            <ul class="nav navbar-right top-nav">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> Xin chào:&nbsp; <?php if (isset($_SESSION['taikhoan'])) {echo $_SESSION['taikhoan'];} {
                    } ?> <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="#"><i class="fa fa-fw fa-user"></i> Profile</a>
                        </li>                        
                        <li>
                            <a href="/index.php"><i class="fa fa-fw fa-gear"></i>Về Trang Chủ</a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="thoatadmin.php"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>
       
            <?php 
            include('includes/sidebar.php');
            ?>
          
        </nav>
        <div id="page-wrapper" >

            <div class="container-fluid">

           