<?php include('../inc/myconnect.php'); ?>
<?php include('../inc/functionKT.php'); ?>
<?php include('includes/header.php'); ?>
<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<h3>Danh sách Sản phẩm</h3>
		<table class="table table-hover">
			<thead>
				<tr>
					<th>ID</th>
					<th>Danh Mục</th>
					<th>Tên SP</th>
					<th>Giá Tiền</th>
					
					<th>Ảnh</th>
					<th>Thứ tự</th>
					<th>Trạng thái</th>
					<th>Sửa</th>
					<th>Xóa</th>
				</tr>
			</thead>
			<tbody>
				<?php 
				
				$limit=8;
				
				if(isset($_GET['s']) && filter_var($_GET['s'],FILTER_VALIDATE_INT,array('min_range'=>1)))
				{
					$start=$_GET['s'];
				}
				else
				{
					$start=0;
				}
				if(isset($_GET['p']) && filter_var($_GET['p'],FILTER_VALIDATE_INT,array('min_range'=>1))){
					$per_page=$_GET['p'];
				}
				else
				{
					
					$query_pg="SELECT COUNT(id) FROM tblsanpham";
					$results_pg=mysqli_query($dbc,$query_pg);
					kt_query($results_pg,$query_pg);
					list($record)=mysqli_fetch_array($results_pg,MYSQLI_NUM);
					
					if ($record > $limit) {
						$per_page=ceil($record / $limit);
					}
					else
					{
						$per_page=1;
					}
				}
					$query="SELECT * FROM tblsanpham ORDER BY ordernum LIMIT {$start},{$limit}";
					$result=mysqli_query($dbc,$query);
					while ($sanpham=mysqli_fetch_array($result,MYSQLI_ASSOC)) {
						?>
						<tr>
							<td><?php echo $sanpham['id']; ?></td>
							<td><?php echo $sanpham['danhmuc']; ?></td>
							<td><?php echo $sanpham['tensp']; ?></td>
							<td><?php echo number_format($sanpham['giatien']) ; ?></td>
							<!-- <td><?php echo $sanpham['noidung']; ?></td> -->
							<td><img width="60" src="../<?php echo $sanpham['anh']; ?>"/></td>
							<td><?php echo $sanpham['ordernum']; ?></td>
							<td>
								<?php if ($sanpham['status']==1) {
									echo "Hiển thị";
								}
								else{
									echo "Không hiển thị";
								} ?>
							</td>
							<td><a href="sua_sanpham.php?id=<?php echo $sanpham['id']; ?>"><img width="21" src="../images/icon_edit.png" alt=""></a></td>
							<td><a href="xoa_sanpham.php?id=<?php echo $sanpham['id']; ?>" onclick="return confirm('Bạn có muốn xóa không?');"><img width="21" src="../images/icon_delete.png" alt=""></a></td>
						</tr>
						<?php
					}
				?>
			</tbody>
		</table>
		<?php 
		echo "<ul class='pagination' style='float:right;'>";
				if ($per_page > 1)
				 {
					$current_page=($start / $limit) + 1;
				
					if ($current_page !=1) {
						echo "<li><a href='list_sanpham.php?s=".($start - $limit)."&p={$per_page}'>Back</a></li>";
					}

					for ($i=1; $i <= $per_page; $i++) { 
						if ($i!=$current_page) {
						echo "<li><a href='list_sanpham.php?s=".($limit*($i-1))."&p={$per_page}'>{$i}</a></li>";
						}
						else
						{
							echo "<li class='active'><a>{$i}</a></li>";
						}
					}
				
					if ($current_page !=$per_page) {
						echo "<li><a href='list_sanpham.php?s=".($start + $limit)."&p={$per_page}'>Next</a></li>";
					}
				}
				echo "</ul>";
				 ?>
	</div>
</div>
<?php include('includes/footer.php') ?>
