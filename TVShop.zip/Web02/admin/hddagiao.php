<?php include('includes/header.php'); ?>
<?php include('../inc/myconnect.php');?>
<?php include('../inc/functionKT.php');?>
<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<h3>Đơn đã hoàn thành</h3>
		<table class="table table-hover">
			<thead>
				<tr align="center">
					<th>Mã HD</th>
					<th>Tên khách hàng</th>
					<th>Địa chỉ</th>
					<th>Tổng tiền</th>
					<th>Trạng thái</th>
					<th>Chi tiết</th>
					
				</tr>
			</thead>
			<tbody>
				<?php 
					
				$query="SELECT * FROM tblhoadonxuat WHERE status = '1' ORDER BY idHDX DESC";
				$result=mysqli_query($dbc,$query);
				kt_query($result,$query);
				while ($hdx=mysqli_fetch_array($result,MYSQLI_ASSOC)) {
					?>
					<tr>
						<td><?php echo $hdx['idHDX']; ?></td>
						<td><?php echo $hdx['tenkhachhang']; ?></td>
						<td><?php echo $hdx['diachi']; ?></td>
						<td><?php echo number_format($hdx['tongtien']) ; ?> VNĐ</td>
						<td>Đã hoàn thành</td>
						<td>
							  <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#myModal">Chi tiết</button>

							  <div class="modal fade" id="myModal" role="dialog">
							    <div class="modal-dialog">
							    
							      <div class="modal-content">
							        <div class="modal-header">
							          <button type="button" class="close" data-dismiss="modal">&times;</button>
							          <h4 class="modal-title">Chi tiết đơn hàng</h4>
							        </div>
							        <div class="modal-body">
							          <p><table class="table table-hover">
							          	<tr align="center">
							          		<th>Mã HD</th>
							          		<th>Tên KH</th>
							          		<th>Email</th>
							          		<th>Số điện thoại</th>
							          		<th>Địa chỉ nhận</th>
							          	</tr>
							          	<tr>
							          		<td><?php echo $hdx['idHDX']; ?></td>
							          		<td><?php echo $hdx['tenkhachhang']; ?></td>
							          		<td><?php echo $hdx['email']; ?></td>
							          		<td><?php echo $hdx['sodienthoai']; ?></td>
							          		<td><?php echo $hdx['diachinhan']; ?></td>
							          	</tr>
							          </table></p>
							        </div>
							        <div class="modal-footer">
							          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							        </div>
							      </div>
							      
							    </div>
							  </div>
						</td>
						
						
					</tr>
					<?php
				}
				?>
			</tbody>
		</table>
	</div>
</div>
<?php include ('includes/footer.php');?>