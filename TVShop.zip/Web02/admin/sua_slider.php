<?php ob_start(); ?>
<?php error_reporting(0);?> 
<?php
include('includes/header.php');
?>
<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<?php 
		include('../inc/myconnect.php');
		include('../inc/functionKT.php');
    
		if(isset($_GET['id']) && filter_var($_GET['id'],FILTER_VALIDATE_INT,array('min_ranger'=>1)))
		{
			$id=$_GET['id'];
		}
		else
		{
			header('Location: list_slider.php');
			exit();
		}
		if (isset($_POST['submit'])) 
		{
			$title=$_POST['title'];
			$link=$_POST['link'];
			$ordernum=$_POST['ordernum'];
			$status=$_POST['status'];

			if($_FILES['img']['size']=='')
			{
			$link_img=$_POST['anh_hid'];
			$thumb=$_POST['anhthumb_hid'];
			}
		else{
			
			if (($_FILES['img']['type']!="image/gif")
				&&($_FILES['img']['type']!="image/png")
				&&($_FILES['img']['type']!="image/jpeg")
				&&($_FILES['img']['type']!="image/jpg")) 
			{
				$message="File không đúng định dạng";
		}
		elseif ($_FILES['img']['size']>1000000) {
			$message="Kích thước phải nhỏ hơn 1MB";
		}
		
		else{
			$img=$_FILES['img']['name'];
			$link_img='upload/'.$img;
			move_uploaded_file($_FILES['img']['tmp_name'],"../upload/".$img);
		}
		
		$sql="SELECT anh,anh_thumb FROM tblslider WHERE id={$id}";
		$query_a=mysqli_query($dbc,$sql);
		$anhInfo=mysqli_fetch_assoc($query_a);
		unlink('../'.$anhInfo['anh']);

	}
		$query="UPDATE tblslider SET title='{$title}',anh='{$link_img}',anh_thumb='{$thumb}',ordernum={$ordernum},status={$status} WHERE id={$id}";//kiểu số ko cần dấu nháy
		$results=mysqli_query($dbc,$query);
		kt_query($results,$query);
       if(mysqli_affected_rows($dbc)==1)
       {
       	echo "<h2 style='color:green;'>Sửa thành công</h2>";
       }
       else
       {
       	echo "<p>Sửa không thành công</p>";
       }
   }
   $query_id="SELECT title,anh,anh_thumb,link,ordernum,status FROM tblslider WHERE id={$id}";
   $result_id=mysqli_query($dbc,$query_id);
   kt_query($query_id,$result_id);
   
   if (mysqli_num_rows($result_id)==1) {
   	list($title,$anh,$anh_thumb,$link,$ordernum,$status)=mysqli_fetch_array($result_id,MYSQLI_NUM);
   }
   else
   {
   	echo "Id slider không tồn tại";
   }
   ?>
   <form moaction="" name="frmadd_slider" method="POST" enctype="multipart/form-data">
   	<h2>Sửa slider: <?php if (isset($title)) { echo $title;  } ?></h2>
   	<div class="form-group">
   		<label for="">Title</label>
   		<input type="text" name="title" class="form-control" placeholder="Tiêu đề" value=" <?php if(isset($title)){echo $title;} ?>">
   	</div>
   	<div class="form-group">
   		<label for="">Ảnh</label>
   		<p><img src="../<?php echo $anh; ?>" width="100" alt=""></p>
   		<input type="hidden" name="anh_hid" value=" <?php echo $anh; ?> ">
   		<input type="hidden" name="anhthumb_hid" value=" <?php echo $anh_thumb; ?> ">
   		<input type="file" name="img" value="">
   	</div>
   	<div class="form-group">
   		<label for="">Link</label>
   		<input type="text" name="link" class="form-control" placeholder="Link slider" value=" <?php if(isset($link)){echo $link;} ?> ">
   	</div>
   	<div class="form-group">
   		<label for="">Thứ tự</label>
   		<input type="text" name="ordernum" class="form-control" placeholder="Thứ tự" value=" <?php if(isset($ordernum)){echo $ordernum;} ?> ">
   	</div>
   	<div class="form-group">
   		<label for="" style="display: block;">Trạng thái</label>
   		<?php 
   		if (isset($status)==1) 
   		{ 
   			?>
   			<label for="" class="radio-inline"><input checked="checked" type="radio" name="status" value="1" >Hiển thị</label>
   			<label for="" class="radio-inline"><input type="radio" name="status" value="0">Không hiển thị</label>
   			<?php 
   		}
   		else
   		{
   			?>
   			<label for="" class="radio-inline"><input type="radio" name="status" value="1">Hiển thị</label>
   			<label for="" class="radio-inline"><input checked="checked" type="radio" name="status" value="0" >Không hiển thị</label>
   			<?php 
   		}
   		?>   
   	</div>
   	<input type="submit" name="submit" class="btn btn-primary" value="Sửa">
   	<input type="reset" name="reset" class="btn btn-primary" value="Reset">
   </form>
</div>
</div>
<?php
include('includes/footer.php');
?>
<?php ob_flush(); ?>

