<?php include('../inc/myconnect.php');?>
<?php include('../inc/functionKT.php');?>
<?php 
	if(isset($_GET['idHDX']) && filter_var($_GET['idHDX'],FILTER_VALIDATE_INT,array('min_ranger'=>1)))
		{
			$idHDX=$_GET['idHDX'];
		}
		$trth=1;
		$querydg = "UPDATE tblhoadonxuat SET status = {$trth} WHERE idHDX = {$idHDX}"; 
		$resultsdg=mysqli_query($dbc,$querydg);
		kt_query($resultsdg,$querydg);
       if(mysqli_affected_rows($dbc)==1)
       {
       	echo "<script>alert('Xác nhận đã giao hàng...!')</script>";
       	header('Location: hddagiao.php');
       }
       else
       {
       	echo "<p>Thao tác thất bại</p>";
       }


?>