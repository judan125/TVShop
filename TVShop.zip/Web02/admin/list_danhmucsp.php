<?php include('includes/header.php'); ?>
<?php include('../inc/myconnect.php');?>
<?php include('../inc/functionKT.php');?>
<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<h3>Danh sách Danh mục</h3>
		<table class="table table-hover">
			<thead>
				<tr align="center">
					<th>ID</th>
					<th>Danh mục</th>
					<th>Thứ tự</th>
					<th>Trạng thái</th>
					<th>Edit</th>
					<th>Delete</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					
				$query="SELECT * FROM tbldanhmuc ORDER BY ordernum DESC";
				$result=mysqli_query($dbc,$query);
				kt_query($result,$query);
				while ($danhmuc=mysqli_fetch_array($result,MYSQLI_ASSOC)) {
					?>
					<tr>
						<td><?php echo $danhmuc['id']; ?></td>
						<td><?php echo $danhmuc['danhmuc']; ?></td>
						<td><?php echo $danhmuc['ordernum']; ?></td>
						<td>
							<?php
							if( $danhmuc['status']==1)
							{
								echo "Hiển thị";
							}
							else {
								echo "Không hiển thị";
							} ?>
							
						</td>
						<td><a href="sua_danhmuc.php?id=<?php echo $danhmuc['id']; ?>"><img width="21" src="../images/icon_edit.png" alt=""></a></td>
						<td><a href="xoa_danhmuc.php?id=<?php echo $danhmuc['id']; ?>" onclick="return confirm('Bạn có muốn xóa không?');"><img width="21" src="../images/icon_delete.png" alt=""></a></td>
					</tr>
					<?php
				}
				?>
			</tbody>
		</table>
	</div>
</div>
<?php include ('includes/footer.php');?>