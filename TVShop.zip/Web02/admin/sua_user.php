<?php ob_start(); ?>
<style type="text/css">
.required
{
	color:red;
}
</style>
<?php include('includes/header.php') ?>
<div class="row">
	<div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
		<?php 
			include('../inc/myconnect.php');
			include('../inc/functionKT.php');
			
			if(isset($_GET['iduser']) && filter_var($_GET['iduser'],FILTER_VALIDATE_INT,array('min_range'=>1)))
			{
				$id=$_GET['iduser'];
			}
			else
			{
				header('Location: list_user.php');
				exit();
			}
			if($_SERVER['REQUEST_METHOD']=='POST')
			{
				$errors=array();						
				if(empty($_POST['hoten']))
				{
					$errors[]='hoten';
				}
				else
				{
					$hoten=$_POST['hoten'];
				}
				if(empty($_POST['dienthoai']))
				{
					$errors[]='dienthoai';
				}
				else
				{
					$dienthoai=$_POST['dienthoai'];
				}
				if (empty($_POST['email'])) 
    			{
    				$errors[]='email';
    			}
    			else
    			{
    				$email=$_POST['email'];
    			}				
				if(empty($_POST['diachi']))
				{
					$errors[]='diachi';
				}
				else
				{
					$diachi=$_POST['diachi'];
				}
				
				$status=$_POST['status'];
				if(empty($errors))
				{													
					$query_in="UPDATE tbluser
								SET hoten='{$hoten}',
									dienthoai='{$dienthoai}',
									email='{$email}',
									diachi='{$diachi}',	
														
									status={$status}
								WHERE iduser={$id}	
							";
					$results_in=mysqli_query($dbc,$query_in);
					kt_query($results_in,$query_in);
					if(mysqli_affected_rows($dbc)==1)
					{
						echo "<p style='color:green;'>Sửa thành công</p>";
						header('Location: list_user.php');
					}
					else
					{
						echo "<p class='required'>Bạn chưa sửa gì</p>";	
					}					
				}
				else
				{
					$message="<p class='required'>Bạn hãy nhập đầy đủ thông tin</p>";
				}
			}
			$query_id="SELECT taikhoan,hoten,dienthoai,email,diachi,quyen,status FROM tbluser WHERE iduser={$id}";
			$results_id=mysqli_query($dbc,$query_id);
			kt_query($results_id,$query_id);
			
			if(mysqli_num_rows($results_id)==1)
			{
				
				list($taikhoan,$hoten,$dienthoai,$email,$diachi,$role,$status)=mysqli_fetch_array($results_id,MYSQLI_NUM);				
			}
			else
			{
				$message="<p class='required'>ID user không tồn tại</p>";
			}
		?>
		<form name="frmsua_user" method="POST">
			<?php 
				if(isset($message))
				{
					echo $message;
				}
			?>
			<h3>Sửa User</h3>
			<div class="form-group">
				<label>Tài khoản</label>
				<input type="text" name="taikhoan" value="<?php if(isset($taikhoan)){ echo $taikhoan;} ?>" class="form-control" placeholder="Tài khoản" readonly="true">				
				<?php 
					if(isset($errors) && in_array('taikhoan',$errors))
					{
						echo "<p class='required'>Tài khoản không để trống</p>";
					}
				?>
			</div>							
			<div class="form-group">
				<label>Họ tên</label>
				<input type="text" name="hoten" value="<?php if(isset($hoten)){ echo $hoten;} ?>" class="form-control" placeholder="Họ tên">				
				<?php 
					if(isset($errors) && in_array('hoten',$errors))
					{
						echo "<p class='required'>Họ tên không để trống</p>";
					}
				?>
			</div>	
			<div class="form-group">
				<label>Số điện thoại</label>
				<input type="number" name="dienthoai" value="<?php if(isset($dienthoai)){ echo $dienthoai;} ?>" class="form-control" placeholder="Điện thoại">				
				<?php 
					if(isset($errors) && in_array('dienthoai',$errors))
					{
						echo "<p class='required'>Điện thoại không để trống</p>";
					}
				?>
			</div>	
			<div class="form-group">
				<label>Email</label>
				<input type="email" name="email" value="<?php if(isset($email)){ echo $email;} ?>" class="form-control" placeholder="Email">				
				<?php 
					if(isset($errors) && in_array('email',$errors))
					{
						echo "<p class='required'>Email không được để trống</p>";
					}
				?>
			</div>	
			<div class="form-group">
				<label>Địa chỉ</label>
				<input type="text" name="diachi" value="<?php if(isset($diachi)){ echo $diachi;} ?>" class="form-control" placeholder="Địa chỉ">				
				<?php 
					if(isset($errors) && in_array('diachi',$errors))
					{
						echo "<p class='required'>Địa chỉ không để trống</p>";
					}
				?>
			</div>			
			
			<div class="form-group">
				<label style="display:block;">Trạng thái</label>
				<?php 
					if($status==1)
					{
					?>
					<label class="radio-inline"><input checked="checked" type="radio" name="status" value="1">Hoạt động</label>
					<label class="radio-inline"><input type="radio" name="status" value="0">Không hoạt động</label>
					<?php 
					}
					else
					{
					?>
					<label class="radio-inline"><input type="radio" name="status" value="1">Hoạt động</label>
					<label class="radio-inline"><input checked="checked" type="radio" name="status" value="0">Không hoạt động</label>
					<?php		
					}
				?>
			</div>
			<input type="submit" name="submit" class="btn btn-primary" value="Sửa">
		</form>
	</div>
</div>
<?php include('includes/footer.php') ?>
<?php ob_flush(); ?>