<?php ob_start(); ?>
<?php
include('includes/header.php');
?>
<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
    <?php 
    include('../inc/myconnect.php');
    include('../inc/functionKT.php');
    if(isset($_GET['id']) && filter_var($_GET['id'],FILTER_VALIDATE_INT,array('min_ranger'=>1)))
    {
      $id=$_GET['id'];
    }
    else
    {
      header('Location: listvideo.php');
      exit();
    }
    if (isset($_POST['submit'])) {
       $title=$_POST['title'];
       $link=$_POST['link'];
       $ordernum=$_POST['ordernum']; 
       $status=$_POST['status'];
       $query="UPDATE tblvideo SET title='{$title}',link='{$link}',ordernum={$ordernum},status={$status} WHERE id={$id} ";
       $results=mysqli_query($dbc,$query);
        kt_query($results,$query);
       if(mysqli_affected_rows($dbc)==1)
       {
        echo "<h2 style='color:green;'>Sửa thành công</h2>";
       }
       else
       {
        echo "<p>Sửa không thành công</p>";
       }
     } 
     $query_id="SELECT title,link,ordernum,status FROM tblvideo WHERE id={$id}";
     $result_id=mysqli_query($dbc,$query_id);
     kt_query($query_id,$result_id);
     
     if (mysqli_num_rows($result_id)==1) {
       list($title,$link,$ordernum,$status)=mysqli_fetch_array($result_id,MYSQLI_NUM);
     }
     else
     {
      echo "Id video không tồn tại";
     }
     ?>
          <form moaction="" name="frmadd_video" method="POST">
            <h2>Sửa video: <?php if(isset($title)){ echo $title;} ?></h2>
            <div class="form-group">
              <label for="">Title</label>
              <input type="text" name="title" value="<?php if(isset($title)){ echo $title;} ?>" class="form-control" placeholder="Tiêu đề">
            </div>
            <div class="form-group">
              <label for="">Link</label>
              <input type="text" name="link" value="<?php if(isset($link)){ echo $link;} ?>" class="form-control" placeholder="Video">
            </div>
            <div class="form-group">
              <label for="">Thứ tự</label>
              <input type="text" name="ordernum" value="<?php if(isset($ordernum)){ echo $ordernum;} ?>" class="form-control" placeholder="Thứ tự">
            </div>
            <div class="form-group">
              <label for="" style="display: block;">Trạng thái</label>
              <label for="" class="radio-inline"><input type="radio" name="status" value="1" checked="checked">Hiển thị</label>
              <label for="" class="radio-inline"><input type="radio" name="status" value="0">Không hiển thị</label>
            </div>
            <input type="submit" name="submit" class="btn btn-primary" value="Sửa">
          </form>
      </div>
</div>
<?php
include('includes/footer.php');
?>
<?php ob_flush(); ?>

