<?php 
include('includes/header.php');
?>
<div class="row">
	<div class="col-lg-12">
		<h1 class="page-header">
			Thông tin nhà phát triển trang web
		</h1>

		<table border="0" cellspacing="0" cellpadding="5" width="800" >
			<tr>
				<td rowspan="9"><img src="../images/user.png" alt="" width="200" height="170"><br>
		</td>
				<th>Tên các nhà phát triển: </th>
				<td>LuanTruong IT</td>
			</tr>
			<tr>
				<th>Số Điện Thoại:</th>
				<td>039743846</td>
			</tr>
			<tr>
				<th>Giới Tính:</th>
				<td>Nam</td>
			</tr>
			<tr>
				<th>Ngày hoàn thành website:</th>
				<td>4/04/2023</td>
			</tr>
			<tr>
				<th>Email:</th>
				<td><a href="mailto:luantruongIT@gmail.com">luantruongIT@gmail.com</a></td>
			</tr>
			<tr>
				<th>Địa chỉ:</th>
				<td>Thủ Đức-Hồ Chí Minh</td>
			</tr>
		</table>
	</div>
</div>


<?php
include ('includes/footer.php');
?>