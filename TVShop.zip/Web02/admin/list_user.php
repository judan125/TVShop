<?php include('includes/header.php'); ?>
<?php include('../inc/myconnect.php');?>
<?php include('../inc/functionKT.php');?>
<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<h3>Danh sách User</h3>
		<table class="table table-hover">
			<thead>
				<tr align="center">
					<th>ID</th>
					<th>Tài khoản</th>
					<th>Họ tên</th>
					<th>Điện thoại</th>
					<th>Email</th>
					<th>Địa chỉ</th>
					<th>Trạng thái</th>
					<th>Edit</th>
					<th>Delete</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					
				$query="SELECT iduser,taikhoan,hoten,dienthoai,email,diachi,status FROM tbluser ORDER BY iduser";
				$result=mysqli_query($dbc,$query);
				kt_query($result,$query);
				
				while ($user=mysqli_fetch_array($result,MYSQLI_ASSOC)) {
					?>
					<tr>
						<td><?php echo $user['iduser']; ?></td>
						<td><?php echo $user['taikhoan']; ?></td>
						<td><?php echo $user['hoten']; ?></td>
						<td><?php echo $user['dienthoai']; ?></td>
						<td><?php echo $user['email']; ?></td>
						<td><?php echo $user['diachi']; ?></td>
						<td>
							<?php
							if( $user['status']==1)
							{
								echo "Hoạt động";
							}
							else {
								echo "Không hoạt động";
							} ?>
							
						</td>
						<td><a href="sua_user.php?iduser=<?php echo $user['iduser']; ?>"><img width="21" src="../images/icon_edit.png" alt=""></a></td>
						<td><a href="xoa_user.php?iduser=<?php echo $user['iduser']; ?>" onclick="return confirm('Bạn có muốn xóa không?');"><img width="21" src="../images/icon_delete.png" alt=""></a></td>
					</tr>
					<?php
				}
				?>
			</tbody>
		</table>
	</div>
</div>
<?php include ('includes/footer.php');?>