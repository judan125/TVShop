<?php
include('includes/header.php');
?>
<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
    <?php 
    include('../inc/myconnect.php');
    include('../inc/functionKT.php');
    if (isset($_POST['submit'])) {
       $title=$_POST['title'];
       $link=$_POST['link'];
       $ordernum=$_POST['ordernum'];
       $status=$_POST['status'];
       if (($_FILES['img']['type']!="image/gif")
        &&($_FILES['img']['type']!="image/png")
        &&($_FILES['img']['type']!="image/jpeg")
        &&($_FILES['img']['type']!="image/jpg")) {
        echo "<h1>File không đúng định dạng ảnh { png,jpg,gif,jpeg }</h1>";
      exit();
       }

       else{
        $img=$_FILES['img']['name'];
        $link_img='upload/'.$img;
        move_uploaded_file($_FILES['img']['tmp_name'],"../upload/".$img);
       }
       $query="INSERT INTO tblslider(title,anh,link,ordernum,status) VALUES('{$title}','{$link_img}','{$link}',$ordernum,$status)";
       $results=mysqli_query($dbc,$query);
       kt_query($results,$query);
       if(mysqli_affected_rows($dbc)==1)
       {
        echo "<h2 style='color:green;'>Thêm mới thành công</h2>";
       }
       else
       {
        echo "<p>Thêm mới không thành công</p>";
       }
     } 
     ?>
          <form moaction="" name="frmadd_slider" method="POST" enctype="multipart/form-data">
            <h2>Thêm mới slider</h2>
            <div class="form-group">
              <label for="">Title</label>
              <input type="text" name="title" class="form-control" placeholder="Tiêu đề">
            </div>
            <div class="form-group">
              <label for="">Ảnh</label>
              <input type="file" name="img" value="">
            </div>
            <div class="form-group">
              <label for="">Link</label>
              <input type="text" name="link" class="form-control" placeholder="Link slider">
            </div>
            <div class="form-group">
              <label for="">Thứ tự</label>
              <input type="text" name="ordernum" class="form-control" placeholder="Thứ tự">
            </div>
            <div class="form-group">
              <label for="" style="display: block;">Trạng thái</label>
              <label for="" class="radio-inline"><input type="radio" name="status" value="1" checked="checked">Hiển thị</label>
              <label for="" class="radio-inline"><input type="radio" name="status" value="0">Không hiển thị</label>
            </div>
            <input type="submit" name="submit" class="btn btn-primary" value="Thêm">
          </form>
      </div>
</div>
<?php
include('includes/footer.php');
?>

