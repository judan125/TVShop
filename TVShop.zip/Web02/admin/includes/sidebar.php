<div class="collapse navbar-collapse navbar-ex1-collapse">
    <ul class="nav navbar-nav side-nav">
        <li style="background:#1b926c;color:#fff;">
            <a href="index.php" style="color:#fff;"><i class="fa fa-fw fa-dashboard"></i> Thông tin</a>
        </li>                    
        <li>
            <a href="javascript:;" data-toggle="collapse" data-target="#demo_dm"><i class="glyphicon glyphicon-list"></i> &nbsp;Danh mục sản phẩm <i class="fa fa-fw fa-caret-down"></i></a>
            <ul id="demo_dm" class="collapse">
                <li>
                    <a href="them_danhmucsp.php">Thêm mới</a>
                </li>
                <li>
                    <a href="list_danhmucsp.php">Danh sách</a>
                </li>
            </ul>
        </li> 
        <li>
            <a href="javascript:;" data-toggle="collapse" data-target="#demo_bv"><i class="glyphicon glyphicon-blackboard"></i>&nbsp; Sản phẩm <i class="fa fa-fw fa-caret-down"></i></a>
            <ul id="demo_bv" class="collapse">
                <li>
                    <a href="them_sanpham.php">Thêm mới</a>
                </li>
                <li>
                    <a href="list_sanpham.php">Danh sách</a>
                </li>
            </ul>
        </li>
       
        <li>
            <a href="javascript:;" data-toggle="collapse" data-target="#demo_u"><i class="glyphicon glyphicon-list"></i> &nbsp;Hóa đơn bán <i class="fa fa-fw fa-caret-down"></i></a>
            <ul id="demo_u" class="collapse">
                <li>
                    <a href="hoadonban.php">Đang chờ</a>
                </li>
                <li>
                    <a href="hddagiao.php">Đã giao</a>
                </li>
            </ul>
        </li> 
        <li>
            <a href="javascript:;" data-toggle="collapse" data-target="#demo_us"><i class="glyphicon glyphicon-user"></i> &nbsp;User <i class="fa fa-fw fa-caret-down"></i></a>
            <ul id="demo_us" class="collapse">
                <li>
                    <a href="them_user.php">Thêm mới</a>
                </li>
                <li>
                    <a href="list_user.php">Danh sách</a>
                </li>
            </ul>
        </li>  	
        <li>
            <a href="javascript:;" data-toggle="collapse" data-target="#demo_tk"><i class="glyphicon glyphicon-statistics"></i> &nbsp;Thống kê <i class="fa fa-fw fa-caret-down"></i></a>
            <ul id="demo_tk" class="collapse">
                <li>
                    <a href="thongkengay.php">Doanh Thu Ngày</a>
                </li>
                <li>
                    <a href="thongkethang.php">Doanh Thu Tháng</a>
                </li>
                <li>
                    <a href="thongkenam.php">Doanh Thu Năm</a>
                </li> 
            </ul>
        </li>				
    </ul>
</div>