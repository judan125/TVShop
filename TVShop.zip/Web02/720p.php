<?php include('includes/header.php') ?>
<?php include('includes/slider.php') ?>
<div class="row">
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" id="left">
       <?php include('includes/left.php') ?>
   </div>
   <div class="col-lg-9 col-md-9 col-sm-9 col-xs-9" id="center">
       <div class="box_center">
           <div class="box_center_top">
            <div class="box_center_top_l">
                <a href="">Độ phân giải 720P</a>     
            </div>
            <div class="box_center_top_r"></div>
            <div class="clearfix"></div>
        </div>
        <div class="box_center_main">
            <div class="row">
					<br>
					<?php 
					$query="SELECT * FROM tblsanpham WHERE phangiai='720' LIMIT 12";
					$results=mysqli_query($dbc,$query);
					kt_query($results,$query);
					while ($sanphamsp=mysqli_fetch_array($results,MYSQLI_ASSOC)) {
						?>
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
							<div class="sanpham_item" align="center">
								<a href="sanphamchitiet.php?id=<?php echo $sanphamsp['id']; ?>"><img src="<?php echo $sanphamsp['anh']; ?>"></a>
								<br>
								<a href="sanphamchitiet.php?id=<?php echo $sanphamsp['id']; ?>" title=""> <?php echo $sanphamsp["tensp"]; ?> </a>
								<br>
								<span style="size: 12px;">
		                        <?php if (isset($sanphamsp['giakm'])) { ?>
		                                Giá: <b style="font-size: 16px;"><?php echo number_format($sanphamsp['giakm']); ?></b> VNĐ
		                                <p style="text-decoration: line-through; color: grey;margin-left: 30px;"><?php echo number_format($sanphamsp['giatien']); ?> VNĐ</p>
		                            <?php } else { ?>
		                                Giá: <?php echo number_format($sanphamsp['giatien'],0,'.','.') ; ?> VNĐ<br>
		                            <?php } ?></span>
								<a href="sanphamchitiet.php?id=<?php echo $sanphamsp['id']; ?>" title=""><input type="button" class="btn btn-secondary" value="<< Xem Chi Tiết >>"></a>
							</div>
							</div>
					<?php
				}
				?>
			</div>
		</div>
			</div>
		</div>
	</div>
<?php 
include('includes/footer.php');
?>

