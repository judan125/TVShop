<?php
include('includes/header.php');
?>
<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
    <?php 
    include('../inc/myconnect.php');
    include('../inc/functionKT.php');
    if (isset($_POST['submit'])) {
       $danhmuc=$_POST['danhmuc'];
       $ordernum=$_POST['ordernum'];
       $status=$_POST['status'];
       $query="INSERT INTO tbldanhmuc(danhmuc,ordernum,status) VALUES ('{$danhmuc}',$ordernum,$status)";
       $results=mysqli_query($dbc,$query);
       kt_query($results,$query);
       if(mysqli_affected_rows($dbc)==1)
       {
        echo "<h2 style='color:green;'>Thêm mới thành công</h2>";
       }
       else
       {
        echo "<p>Thêm mới không thành công</p>";
       }
     } 
     ?>
          <form moaction="" name="frmadd_danhmuc" method="POST">
	<?php 

	?>
	<h2>Thêm mới danh mục sản phẩm</h2>
	<div class="form-group">
		<label for="">Danh mục sản phẩm</label>
		<input type="text" name="danhmuc" class="form-control" placeholder="Danh mục sản phẩm">
		<?php 
              
              ?>
          </div>
          
          <div class="form-group">
          	<label for="">Thứ tự</label>
          	<input type="text" name="ordernum" class="form-control" placeholder="Thứ tự">
          </div>
          <div class="form-group">
          	<label for="" style="display: block;">Trạng thái</label>
          	<label for="" class="radio-inline"><input type="radio" name="status" value="1" checked="checked">Hiển thị</label>
          	<label for="" class="radio-inline"><input type="radio" name="status" value="0">Không hiển thị</label>
          </div>
          <input type="submit" name="submit" class="btn btn-primary" value="Thêm">
      </form>
      </div>
</div>
<?php
include('includes/footer.php');
?>

